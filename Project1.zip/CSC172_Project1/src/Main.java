import java.util.Random;
import java.util.Scanner;

public class Main {
    static int[][] Board = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
    static Random r = new Random();

    public static void print(int[][] Array) {
        System.out.println("\n------------------------");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (j == 0) {
                    System.out.print("|");
                }
                if (Array[i][j] == 0) {
                    System.out.print("    *");
                } else {

                    if (Array[i][j] < 10) {
                        System.out.print("    " + Array[i][j]);
                    } else if (Array[i][j] < 100) {
                        System.out.print("   " + Array[i][j]);
                    } else if (Array[i][j] < 1000) {
                        System.out.print("  " + Array[i][j]);
                    } else {
                        System.out.println(" " + Array[i][j]);
                        if (Array[i][j] == 2048) {
                            System.out.println("YOU WIN");
                        }
                    }
                }
                if (j == 3) {
                    System.out.println("   |");
                }
            }
        }
        System.out.println("------------------------");
    }

    public static void Move(int direction) {
        switch (direction) {
            case 1: //left to right
                for (int i = 0; i < 4; i++) {
                    for(int j = 3; j >= 1; j--) {
                        if (Board[i][j] == Board[i][j - 1]) {
                            Board[i][j - 1] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int j = 1; j < 4; j++) {
                        if (Board[i][j] == 0 && Board[i][j - 1] != 0) {
                            Board[i][j] = Board[i][j - 1];
                            Board[i][j - 1] = 0;
                        }
                    }
                    for(int j = 3; j >= 1; j--) {
                        if (Board[i][j] == Board[i][j - 1]) {
                            Board[i][j - 1] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int j = 1; j < 4; j++) {
                        if (Board[i][j] == 0 && Board[i][j - 1] != 0) {
                            Board[i][j] = Board[i][j - 1];
                            Board[i][j - 1] = 0;
                        }
                    }
                }
                break;
            case 2: //right to left
                for (int i = 0; i < 4; i++) {
                    for (int j = 2; j >= 0; j--) {
                        if (Board[i][j] == 0 && Board[i][j + 1] != 0) {
                            Board[i][j] = Board[i][j + 1];
                            Board[i][j + 1] = 0;
                        }
                    }
                    for (int j = 0; j < 3; j++) {
                        if (Board[i][j] == Board[i][j + 1]) {
                            Board[i][j + 1] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int j = 2; j >= 0; j--) {
                        if (Board[i][j] == 0 && Board[i][j + 1] != 0) {
                            Board[i][j] = Board[i][j + 1];
                            Board[i][j + 1] = 0;
                        }
                    }
                    for (int j = 0; j < 3; j++) {
                        if (Board[i][j] == Board[i][j + 1]) {
                            Board[i][j + 1] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                }
                break;
            case 3: // up to down
                for (int j = 0; j < 4; j++) {
                    for(int i = 3; i >= 1; i--) {
                        if (Board[i][j] == Board[i - 1][j]) {
                            Board[i - 1][j] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int i = 1; i < 4; i++) {
                        if (Board[i][j] == 0 && Board[i - 1][j] != 0) {
                            Board[i][j] = Board[i - 1][j];
                            Board[i - 1][j] = 0;
                        }
                    }
                    for(int i = 3; i >= 1; i--) {
                        if (Board[i][j] == Board[i - 1][j]) {
                            Board[i - 1][j] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int i = 1; i < 4; i++) {
                        if (Board[i][j] == 0 && Board[i - 1][j] != 0) {
                            Board[i][j] = Board[i - 1][j];
                            Board[i - 1][j] = 0;
                        }
                    }
                }
                break;
            case 4: // down to up
                for (int j = 0; j < 4; j++) {
                    for (int i = 2; i >= 0; i--) {
                        if (Board[i][j] == 0 && Board[i + 1][j] != 0) {
                            Board[i][j] = Board[i + 1][j];
                            Board[i + 1][j] = 0;
                        }
                    }
                    for (int i = 0; i < 3; i ++) {
                        if (Board[i][j] == Board[i + 1][j]) {
                            Board[i + 1][j] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                    for (int i = 2; i >= 0; i--) {
                        if (Board[i][j] == 0 && Board[i + 1][j] != 0) {
                            Board[i][j] = Board[i + 1][j];
                            Board[i + 1][j] = 0;
                        }
                    }
                    for (int i = 0; i < 3; i ++) {
                        if (Board[i][j] == Board[i + 1][j]) {
                            Board[i + 1][j] = 0;
                            Board[i][j] *= 2;
                        }
                    }
                }
        }

    }

    public static int randNum() {
        int Ran = r.nextInt(100);
        if (Ran < 20) {
            return 4;
        } else {
            return 2;
        }
    }

    public static void randLoc(int[][] Array) {
        boolean fill = true;
        for(int i = 0; i < 4; i++) {
            for(int j = 0; j < 4; j++) {
                if(Array[i][j] == 0) {
                    fill = false;
                }
            }
        }
        while (fill == false) {
            int Ran = r.nextInt(16);
            int j = Ran / 4;
            int i = Ran % 4;
            if (Array[i][j] == 0) {
                Array[i][j] = randNum();
                return;
            }
        }
        System.out.println("YOU LOSE");
        Board = Reset();
        return;
    }

    public static int[][] Reset() {
        int[][] New = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
        randLoc(New);
        randLoc(New);
        return New;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Boolean Win = false;
        Board = Reset();
        print(Board);
        while (Win == false) {
            Boolean valid = false;
            while (valid == false) {
                String input = scanner.next();
                switch (input) {
                    case "d":
                        Move(1);
                        randLoc(Board);
                        valid = true;
                        break;
                    case "a":
                        Move(2);
                        randLoc(Board);
                        valid = true;
                        break;
                    case "s":
                        Move(3);
                        randLoc(Board);
                        valid = true;
                        break;
                    case "w":
                        Move(4);
                        randLoc(Board);
                        valid = true;
                        break;
                    case "r":
                        System.out.println("ARE YOU SURE? (Y/N)");
                        String reset = scanner.next();
                        if (reset.equalsIgnoreCase("Y")) {
                            Board = Reset();
                        }
                        valid = true;
                        break;
                    case "q":
                        System.out.println("ARE YOU SURE? (Y/N)");
                        String quit = scanner.next();
                        if (quit.equalsIgnoreCase("Y")) {
                            Win = true;
                        }
                        valid = true;
                        break;
                    default:
                        System.out.println("Invalid");
                        break;
                }
            }
            if (Win != true) {
                print(Board);
            }
        }
    }
}

